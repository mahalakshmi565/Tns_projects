<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1772781618454'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/runner/work/spring-tools/spring-tools/eclipse-distribution/org.springframework.boot.ide.product/target/products/org.springframework.boot.ide.branding.springtools/win32/win32/x86_64/sts-5.1.0.RELEASE'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/runner/work/spring-tools/spring-tools/eclipse-distribution/org.springframework.boot.ide.product/target/products/org.springframework.boot.ide.branding.springtools/win32/win32/x86_64/sts-5.1.0.RELEASE'/>
  </properties>
</profile>
